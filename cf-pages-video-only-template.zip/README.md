# Cloudflare Pages: Video-only by ID

## What this does
- Home page: enter an ID, it opens `/v/<id>`
- Route `/v/<id>` returns a "video-only" HTML that embeds the target viewer in a full-screen iframe.

## Deploy (Cloudflare Pages)
1) Create a new GitHub repo and upload this folder contents.
2) Cloudflare Dashboard → Pages → Create a project → Connect to GitHub.
3) Build settings:
   - Framework preset: None
   - Build command: (empty)
   - Output directory: public

## Use
- https://YOURDOMAIN/v/hqohLoWU1
- Or: https://YOURDOMAIN/?id=hqohLoWU1
